﻿namespace OnlineAuction
{
    public class MainModel
    {
        public  string SearchQuery { get; set; }
    }
}